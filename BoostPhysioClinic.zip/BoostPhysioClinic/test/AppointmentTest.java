import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class AppointmentTest {
    private Physiotherapist physio;
    private Patient patient;
    private Treatment treatment;

    @Before
    public void setup() {
        // Initialize common dependencies
        physio = new Physiotherapist(1, "Dr. Smith", "Clinic", "1234567890");
        patient = new Patient("Jane Doe", "Paris", "09876543210");
        treatment = new Treatment("Therapy", "30m", "Pain relief");
    }

    // Existing test
    @Test
    public void testCancelBookedAppointment() {
        Appointment appointment = new Appointment(1, physio, patient, treatment, "2023-10-10 14:00");
        assertTrue(appointment.cancel()); // Successfully cancel
        assertEquals("cancelled", appointment.getStatus());
        assertFalse(appointment.cancel()); // Already cancelled
    }

    // New Test 1: Initial status is "booked"
    @Test
    public void testInitialStatusIsBooked() {
        Appointment appointment = new Appointment(2, physio, patient, treatment, "2023-10-11 10:00");
        assertEquals("booked", appointment.getStatus());
    }

    // New Test 2: Cannot cancel an attended appointment
    @Test
    public void testCancellingAttendedAppointment() {
        Appointment appointment = new Appointment(3, physio, patient, treatment, "2023-10-12 16:00");
        appointment.attend(); // Mark as attended
        assertFalse(appointment.cancel()); // Should fail
        assertEquals("attended", appointment.getStatus());
    }

    // New Test 3: Attend after cancellation fails
    @Test
    public void testAttendAfterCancellation() {
        Appointment appointment = new Appointment(4, physio, patient, treatment, "2023-10-13 09:00");
        appointment.cancel(); // Cancel first
        appointment.attend(); // Try to attend
        assertEquals("cancelled", appointment.getStatus()); // Status remains cancelled
    }

    // New Test 4: Edge case for invalid status transitions
    @Test
    public void testCancelWithInvalidStatus() {
        Appointment appointment = new Appointment(5, physio, patient, treatment, "2023-10-14 11:00");
        appointment.cancel(); // Status: cancelled
        appointment.setTime("2023-10-15 12:00"); // Simulate a change
        assertFalse(appointment.cancel()); // Still cancelled
    }
}