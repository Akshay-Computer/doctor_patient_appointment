public class Patient {
    private static int patientIDCounter = 1;  // Auto-increment counter for Patient IDs
    private int ID;
    private String name;
    private String address;
    private String phone;

    // Constructor now only accepts name, address, and phone
    public Patient(String name, String address, String phone) {
        // Generate a new unique ID for the patient in BookingSystem (auto-incremented)
        this.ID = patientIDCounter++;

        // Validate the phone number (must be 11 digits)
        if (phone.length() != 11 || !phone.matches("\\d+")) {
            System.out.println("Invalid phone number. Please ensure it's 11 digits.");
            return;  // Do not create the patient if the phone number is invalid
        }

        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    // Getters for the fields
    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    // Method to book an appointment, this should be done via BookingSystem, not Patient directly
    public Appointment bookAppointment(BookingSystem bookingSystem, Physiotherapist physiotherapist, Treatment treatment, String time) {
        return bookingSystem.bookAppointment(this, physiotherapist, treatment, time);
    }
}
