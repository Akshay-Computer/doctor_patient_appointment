import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class BookingSystem {
    private List<Patient> patients;
    private List<Physiotherapist> physiotherapists;
    private List<Appointment> appointments;
    private int patientIDCounter = 1;
    private Scanner scanner;

    public BookingSystem() {
        patients = new ArrayList<>();
        physiotherapists = new ArrayList<>();
        appointments = new ArrayList<>();
        scanner = new Scanner(System.in);

        // Predefined patients
        addPredefinedPatients();
    }

    // Add predefined 10 patients
    public void addPredefinedPatients() {
        patients.add(new Patient("Akshay", "Hatfield", "12345678901"));
        patients.add(new Patient("John", "London", "98765432101"));
        patients.add(new Patient("Emma", "New York", "11223344556"));
        patients.add(new Patient("Alice", "Los Angeles", "66778899001"));
        patients.add(new Patient("Sarah", "Chicago", "23456789012"));
        patients.add(new Patient("Bob", "Houston", "34567890123"));
        patients.add(new Patient("Mike", "San Francisco", "45678901234"));
        patients.add(new Patient("James", "Seattle", "56789012345"));
        patients.add(new Patient("Lily", "Boston", "67890123456"));
        patients.add(new Patient("Sophia", "Miami", "78901234567"));

        // Auto-incrementing ID
        patientIDCounter = patients.size() + 1;
    }

    public void addPatient(String patientName, String patientAddress, String patientPhone) {
        // Validate name contains only letters and spaces
        while (patientName.trim().isEmpty() || !patientName.matches("[a-zA-Z ]+")) {
            System.out.println("Invalid name. Please enter only letters and spaces.");
            System.out.print("Enter Patient Name: ");
            patientName = scanner.nextLine();
        }

        // Validate address is not empty
        while (patientAddress.trim().isEmpty()) {
            System.out.println("Patient address cannot be empty.");
            System.out.print("Enter Patient Address: ");
            patientAddress = scanner.nextLine();
        }

        // Validate phone number
        while (patientPhone.trim().length() != 11 || !patientPhone.trim().matches("\\d+")) {
            System.out.println("Invalid phone number. Please ensure it's 11 digits.");
            System.out.print("Enter Patient Phone (11 digits): ");
            patientPhone = scanner.nextLine();
        }

        // Check for duplicate phone number
        for (Patient existingPatient : patients) {
            if (existingPatient.getPhone().equals(patientPhone.trim())) {
                System.out.println("A patient with this phone number already exists.");
                return;
            }
        }

        Patient newPatient = new Patient(patientName.trim(), patientAddress.trim(), patientPhone.trim());
        patients.add(newPatient);

        System.out.println("\nNew patient added:");
        System.out.println("Patient ID: " + newPatient.getID());
        System.out.println("Name: " + newPatient.getName());
        System.out.println("Address: " + newPatient.getAddress());
        System.out.println("Phone: " + newPatient.getPhone());

        patientIDCounter++;
    }

    // Add a physiotherapist
    public void addPhysiotherapist(Physiotherapist physiotherapist) {
        physiotherapists.add(physiotherapist);
    }

    // Book an appointment
    public Appointment bookAppointment(Patient patient, Physiotherapist physiotherapist, Treatment treatment, String time) {
        // Check if the patient exists in the system before proceeding
        if (patient == null) {
            System.out.println("Error: The patient does not exist.");
            return null;  // Exit the method, do not proceed with booking
        }

        time = time.trim();

        while (!isValidDateTime(time)) {
            System.out.println("Invalid time format or value. Please enter the time in the format YYYY-MM-DD HH:MM.");
            System.out.print("Enter Appointment Time (YYYY-MM-DD HH:MM): ");
            time = scanner.nextLine().trim();
        }

        if (!isTimeAvailable(time, physiotherapist)) {
            System.out.println("Error: This time is already booked with " + physiotherapist.getName() + ". Please choose a different time.");
            return null;  // Return null if the time is already booked
        }

        Appointment appointment = new Appointment(appointments.size() + 1, physiotherapist, patient, treatment, time);
        appointments.add(appointment);
        System.out.println("Appointment booked successfully for " + time);
        return appointment;
    }

    // Cancel an appointment
    public void cancelAppointment(Appointment appointment) {
        if (appointment == null) {
            System.out.println("Error: Appointment not found.");
            return;
        }

        if (!appointment.cancel()) {
            System.out.println("Cancellation failed. See message above.");
        } else {
            System.out.println("Appointment cancelled successfully.");
        }
    }



    // Change an appointment
    public void changeAppointment(Appointment appointment) {
        // Add status validation
        if (appointment == null) {
            System.out.println("Error: Appointment not found.");
            return;
        }

        if ("cancelled".equalsIgnoreCase(appointment.getStatus())) {
            System.out.println("Error: Cannot change a cancelled appointment.");
            return;
        }

        // Rest of your original code...
        System.out.print("Enter new appointment time (YYYY-MM-DD HH:MM): ");
        String newTime = scanner.nextLine().trim();

        while (!isValidDateTime(newTime)) {
            System.out.println("Invalid time format. Use YYYY-MM-DD HH:MM.");
            newTime = scanner.nextLine().trim();
        }

        if (!isTimeAvailable(newTime, appointment.getPhysiotherapist())) {
            System.out.println("Error: Time already booked.");
            return;
        }

        appointment.setTime(newTime);
        System.out.println("Appointment changed successfully!");
    }

    // Validate the time format
    public static boolean isValidTimeFormat(String time) {
        return time.matches("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}$");
    }

    // Validate the date-time value
    public static boolean isValidDateTime(String time) {
        if (!isValidTimeFormat(time)) return false;

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime.parse(time, formatter);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    // Check if the time is available for the physiotherapist
    public boolean isTimeAvailable(String time, Physiotherapist physio) {
        return appointments.stream()
                .noneMatch(a ->
                        a.getPhysiotherapist().equals(physio) &&
                                a.getTime().equals(time) &&
                                !"cancelled".equalsIgnoreCase(a.getStatus())
                );
    }

    // Remove a patient
    public void removePatient(int patientID) {
        Patient patientToRemove = null;
        for (Patient patient : patients) {
            if (patient.getID() == patientID) {
                patientToRemove = patient;
                break;
            }
        }

        if (patientToRemove != null) {
            patients.remove(patientToRemove);
            System.out.println("Patient with ID " + patientID + " has been removed.");
        } else {
            System.out.println("Patient ID not found.");
        }
    }

    // Generate report
    public void generateReport() {
        Map<Physiotherapist, Integer> attendedCounts = new HashMap<>();
        for (Physiotherapist physiotherapist : physiotherapists) {
            attendedCounts.put(physiotherapist, 0);
        }

        Map<Physiotherapist, List<Appointment>> physiotherapistAppointments = new HashMap<>();
        for (Appointment appointment : appointments) {
            Physiotherapist physiotherapist = appointment.getPhysiotherapist();
            physiotherapistAppointments.putIfAbsent(physiotherapist, new ArrayList<>());
            physiotherapistAppointments.get(physiotherapist).add(appointment);

            if (appointment.getStatus().equalsIgnoreCase("attended")) {
                attendedCounts.put(physiotherapist, attendedCounts.get(physiotherapist) + 1);
            }
        }

        List<Physiotherapist> sortedPhysiotherapists = new ArrayList<>(physiotherapists);
        sortedPhysiotherapists.sort((p1, p2) -> attendedCounts.get(p2) - attendedCounts.get(p1));

        System.out.println("\n\n");
        System.out.println("╔═════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║                🏥 BOOST PHYSIO CLINIC - APPOINTMENT REPORT 🏥                ║");
        System.out.println("╠═════════════════════════════════════════════════════════════════════════════╣");
        System.out.println("║                                                                             ║");
        System.out.printf("║ %-20s ║ %-25s ║ %-12s ║ %-16s ║ %-8s ║\n",
                "Physiotherapist (Attended: X)", "Treatment", "Patient", "Time", "Status");
        System.out.println("╠══════════════════════════════════╦════════════════════════════════════════╦════════════════╦════════════════╦══════════╣");

        for (Physiotherapist physiotherapist : sortedPhysiotherapists) {
            System.out.printf("║ \u001B[1m%-20s\u001B[0m ║ %-25s ║ %-12s ║ %-16s ║ %-8s ║\n",
                    physiotherapist.getName() + " (✓ " + attendedCounts.get(physiotherapist) + ")", "", "", "", "" );

            List<Appointment> appointmentsForPhysio = physiotherapistAppointments.get(physiotherapist);

            if (appointmentsForPhysio != null && !appointmentsForPhysio.isEmpty()) {
                for (Appointment appointment : appointmentsForPhysio) {
                    String treatmentName = appointment.getTreatment().getTreatmentName();
                    String patientName = appointment.getPatient().getName();
                    String time = appointment.getTime();
                    String status = appointment.getStatus();

                    String formattedStatus = status;
                    if (status.equalsIgnoreCase("attended")) {
                        formattedStatus = "\u001B[32m" + status + "\u001B[0m";
                    } else if (status.equalsIgnoreCase("cancelled")) {
                        formattedStatus = "\u001B[31m" + status + "\u001B[0m";
                    }

                    System.out.printf("║ %-20s ║ %-25s ║ %-12s ║ %-16s ║ %-8s ║\n",
                            "", treatmentName, patientName, time, formattedStatus);
                }
            } else {
                System.out.printf("║ %-20s ║ %-25s ║ %-12s ║ %-16s ║ %-8s ║\n",
                        "❌ No appointments", "", "", "", "");
            }
            System.out.println("╠══════════════════════════════════╬════════════════════════════════════════╬════════════════╬════════════════╬══════════╣");
        }
        System.out.println("╚═════════════════════════════════════════════════════════════════════════════╝");
        System.out.println("\n");
    }

    // Getters
    public List<Physiotherapist> getPhysiotherapists() {
        return physiotherapists;
    }

    public Patient getPatientByID(int id) {
        for (Patient patient : patients) {
            if (patient.getID() == id) {
                return patient;
            }
        }
        return null;
    }

    public Physiotherapist getPhysiotherapistByID(int id) {
        for (Physiotherapist physiotherapist : physiotherapists) {
            if (physiotherapist.getID() == id) {
                return physiotherapist;
            }
        }
        return null;
    }

    public Appointment getAppointmentByID(int id) {
        for (Appointment appointment : appointments) {
            if (appointment.getBookingID() == id) {
                return appointment;
            }
        }
        return null;
    }
}
