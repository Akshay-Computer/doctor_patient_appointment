public class Treatment {
    private String treatmentName;
    private String duration;
    private String description;

    // Constructor to initialize the Treatment object
    public Treatment(String treatmentName, String duration, String description) {
        this.treatmentName = treatmentName;
        this.duration = duration;
        this.description = description;
    }

    // Getter for treatment name
    public String getTreatmentName() {
        return treatmentName;
    }

    // Getter for treatment duration
    public String getDuration() {
        return duration;
    }

    // Getter for treatment description
    public String getDescription() {
        return description;
    }

    // Method to get treatment details
    public String getTreatmentDetails() {
        return "Name: " + treatmentName + ", Duration: " + duration + ", Description: " + description;
    }
}
