import java.util.ArrayList;
import java.util.List;

public class Physiotherapist {
    private int ID;
    private String name;
    private String address;
    private String phone;
    private List<String> expertise;
    private List<Treatment> treatments;

    public Physiotherapist(int ID, String name, String address, String phone) {
        this.ID = ID;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.expertise = new ArrayList<>();
        this.treatments = new ArrayList<>();
    }

    public void addTreatment(Treatment treatment) {
        treatments.add(treatment);
    }

    public void removeTreatment(Treatment treatment) {
        treatments.remove(treatment);
    }

    public List<Treatment> getAvailableTreatments() {
        return treatments;
    }

    public void addExpertise(String expertise) {
        this.expertise.add(expertise);
    }

    public void removeExpertise(String expertise) {
        this.expertise.remove(expertise);
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }
}
