import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Main {
    public static void main(String[] args) {
        // Initialize physiotherapists and treatments
        Physiotherapist physio1 = new Physiotherapist(1, "Dr. Helen", "Address 1", "1234567890");
        Treatment treatment1 = new Treatment("Massage", "1 hour", "Relaxing treatment for muscles.");
        physio1.addTreatment(treatment1);

        Physiotherapist physio2 = new Physiotherapist(2, "Dr. John", "Address 2", "9876543210");
        Treatment treatment2 = new Treatment("Acupuncture", "45 minutes", "Traditional needle therapy.");
        physio2.addTreatment(treatment2);

        Physiotherapist physio3 = new Physiotherapist(3, "Dr. Alice", "Address 3", "3216549870");
        Treatment treatment3 = new Treatment("Rehabilitation", "2 hours", "Physical therapy for recovery.");
        physio3.addTreatment(treatment3);

        Physiotherapist physio4 = new Physiotherapist(4, "Dr. Mike", "Address 4", "8765432109");
        Treatment treatment4 = new Treatment("Osteopathy", "1.5 hours", "Joint manipulation and massage.");
        physio4.addTreatment(treatment4);

        Physiotherapist physio5 = new Physiotherapist(5, "Dr. Sarah", "Address 5", "6543219870");
        Treatment treatment5 = new Treatment("Chiropractic", "1 hour", "Spinal alignment.");
        physio5.addTreatment(treatment5);

        Physiotherapist physio6 = new Physiotherapist(6, "Dr. Max", "Address 6", "2345678901");
        Treatment treatment6 = new Treatment("Sports Therapy", "45 minutes", "Treatment for muscle strains.");
        physio6.addTreatment(treatment6);

        Physiotherapist physio7 = new Physiotherapist(7, "Dr. Emma", "Address 7", "1098765432");
        Treatment treatment7 = new Treatment("Massage Therapy", "1 hour", "Relaxing muscle treatment.");
        physio7.addTreatment(treatment7);

        // Create the booking system
        BookingSystem bookingSystem = new BookingSystem();
        bookingSystem.addPhysiotherapist(physio1);
        bookingSystem.addPhysiotherapist(physio2);
        bookingSystem.addPhysiotherapist(physio3);
        bookingSystem.addPhysiotherapist(physio4);
        bookingSystem.addPhysiotherapist(physio5);
        bookingSystem.addPhysiotherapist(physio6);
        bookingSystem.addPhysiotherapist(physio7);

        // Main loop for interactive system
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            try {
                System.out.println("\n---- Boost Physio Clinic ----");
                System.out.println("1. Add a patient");
                System.out.println("2. Book an appointment");
                System.out.println("3. Cancel an appointment");
                System.out.println("4. Change an appointment");
                System.out.println("5. Attend a treatment appointment");
                System.out.println("6. Print Report");
                System.out.println("7. Remove a patient");
                System.out.println("8. Exit");
                System.out.print("Select an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume the newline character

                switch (choice) {
                    case 1:
                        addPatient(scanner, bookingSystem);
                        break;
                    case 2:
                        bookAppointment(scanner, bookingSystem);
                        break;
                    case 3:
                        cancelAppointment(scanner, bookingSystem);
                        break;
                    case 4:
                        changeAppointment(scanner, bookingSystem);
                        break;
                    case 5:
                        attendAppointment(scanner, bookingSystem);
                        break;
                    case 6:
                        bookingSystem.generateReport();
                        break;
                    case 7:
                        removePatient(scanner, bookingSystem);
                        break;
                    case 8:
                        running = false;
                        System.out.println("Exiting the system...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
                scanner.nextLine();
            }
        }
        scanner.close();
    }

    private static void addPatient(Scanner scanner, BookingSystem bookingSystem) {
        System.out.println("Adding a new patient...");
        String patientName;
        do {
            System.out.print("Enter Patient Name: ");
            patientName = scanner.nextLine().trim();
            if (patientName.isEmpty()) {
                System.out.println("Patient name cannot be empty.");
            } else if (!patientName.matches("[a-zA-Z ]+")) {
                System.out.println("Invalid name. Please use only letters and spaces.");
            }
        } while (patientName.isEmpty() || !patientName.matches("[a-zA-Z ]+"));

        String patientAddress;
        do {
            System.out.print("Enter Patient Address: ");
            patientAddress = scanner.nextLine().trim();
            if (patientAddress.isEmpty()) {
                System.out.println("Patient address cannot be empty.");
            }
        } while (patientAddress.isEmpty());

        String patientPhone;
        do {
            System.out.print("Enter Patient Phone (11 digits): ");
            patientPhone = scanner.nextLine().trim();
            if (patientPhone.length() != 11 || !patientPhone.matches("\\d+")) {
                System.out.println("Invalid phone number. Please ensure it's 11 digits.");
            }
        } while (patientPhone.length() != 11 || !patientPhone.matches("\\d+"));

        bookingSystem.addPatient(patientName, patientAddress, patientPhone);
    }

    private static void bookAppointment(Scanner scanner, BookingSystem bookingSystem) {
        System.out.println("Booking an appointment...");
        System.out.print("Enter Patient ID: ");
        int patientID = getIntInput(scanner);

        System.out.println("\nList of available physiotherapists and their treatments:");
        for (Physiotherapist physiotherapist : bookingSystem.getPhysiotherapists()) {
            System.out.printf("ID: %-3d Name: %-30s\n", physiotherapist.getID(), physiotherapist.getName());
            System.out.println("Available treatments:");
            for (Treatment treatment : physiotherapist.getAvailableTreatments()) {
                System.out.println(" ▪ " + treatment.getTreatmentName() + " - " + treatment.getDuration() + " - " + treatment.getDescription());
            }
        }

        System.out.print("Enter Physiotherapist ID: ");
        int physioID = getIntInput(scanner);

        Physiotherapist physiotherapist = bookingSystem.getPhysiotherapistByID(physioID);
        if (physiotherapist == null) {
            System.out.println("Invalid Physiotherapist ID. Try again.");
            return;
        }

        System.out.print("Enter Treatment Name: ");
        String treatmentName = scanner.nextLine();
        System.out.print("Enter Appointment Time (YYYY-MM-DD HH:MM): ");
        String time = scanner.nextLine();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        dateFormat.setLenient(false);
        while (true) {
            try {
                dateFormat.parse(time);
                break;
            } catch (ParseException e) {
                System.out.println("Invalid time format. Please enter in the format: YYYY-MM-DD HH:MM");
                System.out.print("Enter Appointment Time (YYYY-MM-DD HH:MM): ");
                time = scanner.nextLine();
            }
        }

        Treatment selectedTreatment = null;
        for (Treatment t : physiotherapist.getAvailableTreatments()) {
            if (t.getTreatmentName().equalsIgnoreCase(treatmentName)) {
                selectedTreatment = t;
                break;
            }
        }

        if (selectedTreatment != null) {
            Patient patientObj = bookingSystem.getPatientByID(patientID);
            Appointment appointment = bookingSystem.bookAppointment(patientObj, physiotherapist, selectedTreatment, time);
            if (appointment != null) {
                System.out.println("Appointment booked successfully! " + appointment.getBookingDetails());
            }
        } else {
            System.out.println("Treatment not found. Please check the treatment name.");
        }
    }

    private static void cancelAppointment(Scanner scanner, BookingSystem bookingSystem) {
        System.out.println("Canceling an appointment...");
        System.out.print("Enter Booking ID: ");
        int bookingID = getIntInput(scanner);

        Appointment appointment = bookingSystem.getAppointmentByID(bookingID);
        if (appointment == null) {
            System.out.println("Error: Invalid Booking ID.");
            return;
        }

        bookingSystem.cancelAppointment(appointment); // Handles all validation
    }

    private static void changeAppointment(Scanner scanner, BookingSystem bookingSystem) {
        System.out.println("Changing an appointment...");
        System.out.print("Enter Booking ID to change: ");
        int oldBookingID = getIntInput(scanner);
        Appointment oldAppointment = bookingSystem.getAppointmentByID(oldBookingID);

        if (oldAppointment != null) {
            bookingSystem.changeAppointment(oldAppointment);
        } else {
            System.out.println("Booking ID not found.");
        }
    }

    private static void attendAppointment(Scanner scanner, BookingSystem bookingSystem) {
        System.out.println("Marking an appointment as attended...");
        System.out.print("Enter Booking ID to attend: ");
        int attendBookingID = getIntInput(scanner);
        Appointment attendAppointment = bookingSystem.getAppointmentByID(attendBookingID);
        if (attendAppointment != null) {
            attendAppointment.attend();
            System.out.println("Appointment attended: " + attendAppointment.getBookingDetails());
        } else {
            System.out.println("Appointment not found.");
        }
    }

    private static void removePatient(Scanner scanner, BookingSystem bookingSystem) {
        System.out.print("Enter Patient ID to remove: ");
        int patientID = getIntInput(scanner);

        bookingSystem.removePatient(patientID);  // Calls the removePatient method in BookingSystem
    }


    private static int getIntInput(Scanner scanner) {
        while (true) {
            try {
                int input = scanner.nextInt();
                scanner.nextLine();
                return input;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();
            }
        }
    }
}
