public class Appointment {
    private int bookingID;
    private Physiotherapist physiotherapist;
    private Patient patient;
    private Treatment treatment;
    private String time;
    private String status;

    public Appointment(int bookingID, Physiotherapist physiotherapist, Patient patient,
                       Treatment treatment, String time) {
        this.bookingID = bookingID;
        this.physiotherapist = physiotherapist;
        this.patient = patient;
        this.treatment = treatment;
        this.time = time;
        this.status = "booked"; // Default status
    }

    // ===== FIXED METHODS =====
    public boolean cancel() {
        if ("booked".equalsIgnoreCase(status)) {
            this.status = "cancelled";
            return true;
        }
        System.out.println("Cannot cancel - appointment is already " + status + ".");
        return false;
    }

    public void attend() {
        if ("cancelled".equalsIgnoreCase(status)) {
            System.out.println("Error: Cannot attend a cancelled appointment.");
        } else if (!"attended".equalsIgnoreCase(status)) {
            this.status = "attended";
        }
    }

    // ===== YOUR ORIGINAL METHODS (UNCHANGED) =====
    public String getBookingDetails() {
        return "BookingID: " + bookingID +
                ", Physiotherapist: " + physiotherapist.getName() +
                ", Treatment: " + treatment.getTreatmentDetails() +
                ", Time: " + time +
                ", Status: " + status;
    }

    public int getBookingID() { return bookingID; }
    public String getStatus() { return status; }
    public Physiotherapist getPhysiotherapist() { return physiotherapist; }
    public Patient getPatient() { return patient; }
    public Treatment getTreatment() { return treatment; }
    public String getTime() { return time; }

    public void setTime(String time) {
        if (time != null && !time.isEmpty()) {
            this.time = time;
        } else {
            System.out.println("Invalid time provided.");
        }
    }
}